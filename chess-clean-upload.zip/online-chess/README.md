# Real-Time Online Chess Platform

A production-grade, two-player real-time online chess application featuring server-authoritative move validation, high-precision Blitz & Rapid clocks, instant spectator connections, and disconnect recovery.

---

## Technical Stack

- **Backend (`server/`)**:
  - **Runtime**: Node.js & TypeScript
  - **Real-Time Communication**: WebSockets via `Socket.io`
  - **Chess Engine**: `chess.js` (strict server-side validation; client moves are never trusted)
  - **State / Session Store**: High-performance in-memory room & session store with 30-second disconnect grace period

- **Frontend (`client/`)**:
  - **Framework**: Next.js 14 / React with TypeScript
  - **Styling**: Tailwind CSS with custom glassmorphism & dark gradients
  - **Chess Board**: `react-chessboard` + local legal move hinting
  - **Audio**: Web Audio API synthesized sound effects (move, capture, check, victory)
  - **Celebration**: `canvas-confetti`

---

## Directory Structure

```
online-chess/
├── server/
│   ├── src/
│   │   ├── types/index.ts         # Shared WebSocket event contracts & room models
│   │   ├── game/
│   │   │   ├── ChessGame.ts       # chess.js wrapper (legality, SAN/UCI, checkmate/draw rules)
│   │   │   └── ChessTimer.ts      # Authoritative clock with delta tracking & flag-fall
│   │   ├── store/
│   │   │   └── RoomStore.ts       # In-memory room manager, 6-character room codes, grace periods
│   │   ├── socket/
│   │   │   └── handlers.ts        # WebSocket lifecycle handlers
│   │   ├── server.ts              # HTTP & Socket.io server bootstrap
│   │   └── test-simulation.ts     # Automated E2E integration test (Scholar's Mate)
│   ├── package.json
│   └── tsconfig.json
│
└── client/
    ├── src/
    │   ├── app/
    │   │   ├── page.tsx           # Lobby: Create Game (time control / color) & Join Game
    │   │   ├── game/[roomId]/     # Main Game Room
    │   │   ├── layout.tsx
    │   │   └── globals.css
    │   ├── hooks/
    │   │   └── useChessGame.ts    # Socket.io custom hook with smooth clock interpolation
    │   ├── components/
    │   │   ├── ChessBoardView.tsx # Drag-and-drop & click-to-move, legal dots, check highlight
    │   │   ├── PlayerCard.tsx     # Player info, connection pulse, clock, captured pieces
    │   │   ├── MoveHistory.tsx    # PGN algebraic notation scrollable list
    │   │   ├── GameOverModal.tsx  # Game over dialog with win confetti & rematch logic
    │   │   ├── PromotionModal.tsx # Pawn promotion selector (Q, R, B, N)
    │   │   └── ShareLink.tsx      # Shareable URL with 1-click clipboard copy
    │   ├── utils/
    │   │   └── sound.ts           # Web Audio API synthesizer
    │   └── types/index.ts         # Client-side contracts
    ├── package.json
    └── tailwind.config.ts
```

---

## Getting Started

### 1. Start the Backend Server

```bash
cd online-chess/server
npm install
npm run dev
```
Server will start on `http://localhost:4000`.

To run the automated E2E integration test:
```bash
npm run test:sim
```

### 2. Start the Frontend Application

```bash
cd online-chess/client
npm install
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## WebSocket Event Protocol

### Client-to-Server
| Event | Payload | Description |
|---|---|---|
| `create_room` | `{ timeControl, preferredColor, username }` | Creates a new private room |
| `join_room` | `{ roomId, username, playerId? }` | Joins as Player 2, reconnects, or spectates |
| `make_move` | `{ roomId, playerId, move: { from, to, promotion? } }` | Sends move for server validation |
| `resign` | `{ roomId, playerId }` | Resigns match |
| `offer_draw` | `{ roomId, playerId }` | Proposes a draw to opponent |
| `respond_draw` | `{ roomId, playerId, accept: boolean }` | Accepts or declines draw offer |
| `request_rematch` | `{ roomId, playerId }` | Requests or accepts rematch |

### Server-to-Client
| Event | Payload | Description |
|---|---|---|
| `room_created` | `{ roomId, playerId, color }` | Dispatched to room creator |
| `game_joined` | `{ roomState, yourPlayerId, yourColor, isSpectator }` | Dispatched upon entering room |
| `game_started` | `{ roomState }` | Dispatched when Player 2 joins |
| `move_made` | `{ move, roomState }` | Broadcasts validated move and updated FEN |
| `move_rejected`| `{ error }` | Sent to player if move was illegal |
| `clock_tick` | `{ whiteTimeMs, blackTimeMs, turn }` | Synchronizes authoritative clocks |
| `player_disconnected` | `{ color, username, gracePeriodSeconds }` | Notifies opponent of 30s grace window |
| `player_reconnected` | `{ color, roomState }` | Notifies room when player resumes |
| `game_over` | `{ details, roomState }` | Checkmate, stalemate, timeout, or resignation |
